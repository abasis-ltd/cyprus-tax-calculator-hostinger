/**
 * Storage owner and message switchboard.
 *
 * Two things need coordinating that a content script cannot do alone:
 *   1. The payload arrives on the calculator's tab and is needed on the portal's tab.
 *   2. The portal may render its form inside an iframe, so the panel (top frame) and
 *      the field being bound or filled (any frame) are in different worlds. Every
 *      cross-frame message goes out through here.
 *
 * The worker keeps no state in variables — it is torn down after ~30s idle — so every
 * handler reads from chrome.storage and writes back.
 */

const MAX_ITEMS = 400;
const MAX_PAYLOAD_BYTES = 256 * 1024;

/** Rejects anything that isn't a payload this version understands. */
function validatePayload(payload) {
    if (!payload || typeof payload !== 'object') return 'not-an-object';
    if (payload.source !== 'cyprus-tax-calculator') return 'wrong-source';
    if (payload.version !== 2) return 'unsupported-version';
    if (!Number.isInteger(payload.taxYear) || payload.taxYear < 2025 || payload.taxYear > 2100) return 'bad-year';
    if (!Array.isArray(payload.checks) || payload.checks.some(check => typeof check !== 'string')) return 'bad-checks';
    if (!Array.isArray(payload.items)) return 'no-items';
    if (payload.items.length > MAX_ITEMS) return 'too-many-items';
    if (JSON.stringify(payload).length > MAX_PAYLOAD_BYTES) return 'too-large';
    const ids = new Set();
    const targets = new Set();
    for (const item of payload.items) {
        if (!item || typeof item.id !== 'string' || !item.id) return 'bad-item-id';
        if (typeof item.value !== 'string') return 'bad-item-value';
        if (ids.has(item.id)) return 'duplicate-item-id';
        ids.add(item.id);
        if (item.targetId !== undefined) {
            if (payload.taxYear !== 2025 || !/^(?:fM[3456][A-Z0-9_]+|fld[A-Z0-9_]+)$/.test(item.targetId)) return 'bad-target';
            if (targets.has(item.targetId)) return 'duplicate-target';
            targets.add(item.targetId);
        }
    }
    return null;
}

async function storePayload(payload) {
    const problem = validatePayload(payload);
    if (problem) return { ok: false, reason: problem };
    await chrome.storage.local.set({ payload, receivedAt: new Date().toISOString() });
    await chrome.storage.session.set({ filled: {} });
    await chrome.action.setBadgeText({ text: String(payload.items.length) });
    await chrome.action.setBadgeBackgroundColor({ color: '#4f46e5' });
    return { ok: true, count: payload.items.length };
}

async function getMap(origin) {
    const { maps = {} } = await chrome.storage.local.get('maps');
    return maps[origin] || {};
}

async function saveBinding(origin, itemId, descriptor) {
    const { maps = {} } = await chrome.storage.local.get('maps');
    const forOrigin = { ...(maps[origin] || {}) };
    if (descriptor) forOrigin[itemId] = descriptor;
    else delete forOrigin[itemId];
    await chrome.storage.local.set({ maps: { ...maps, [origin]: forOrigin } });
    return forOrigin;
}

async function markFilled(itemId, written) {
    const { filled = {} } = await chrome.storage.session.get('filled');
    filled[itemId] = { at: new Date().toISOString(), written };
    await chrome.storage.session.set({ filled });
    return filled;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    (async () => {
        try {
            switch (message?.type) {
                case 'STORE_PAYLOAD':
                    sendResponse(await storePayload(message.payload));
                    return;

                case 'GET_STATE': {
                    const { payload = null, receivedAt = null, maps = {} } =
                        await chrome.storage.local.get(['payload', 'receivedAt', 'maps']);
                    const { filled = {} } = await chrome.storage.session.get('filled');
                    sendResponse({
                        ok: true,
                        payload: payload && !validatePayload(payload) ? payload : null,
                        receivedAt,
                        map: message.origin ? (maps[message.origin] || {}) : {},
                        maps,
                        filled,
                    });
                    return;
                }

                case 'SAVE_BINDING':
                    sendResponse({ ok: true, map: await saveBinding(message.origin, message.itemId, message.descriptor) });
                    return;

                case 'GET_MAP':
                    sendResponse({ ok: true, map: await getMap(message.origin) });
                    return;

                case 'MARK_FILLED':
                    sendResponse({ ok: true, filled: await markFilled(message.itemId, message.written) });
                    return;

                case 'CLEAR_ALL':
                    await chrome.storage.local.remove(['payload', 'receivedAt']);
                    await chrome.storage.session.set({ filled: {} });
                    await chrome.action.setBadgeText({ text: '' });
                    sendResponse({ ok: true });
                    return;

                case 'CLEAR_MAP': {
                    const { maps = {} } = await chrome.storage.local.get('maps');
                    delete maps[message.origin];
                    await chrome.storage.local.set({ maps });
                    sendResponse({ ok: true });
                    return;
                }

                // Panel (top frame) → every frame of the same tab.
                case 'BROADCAST': {
                    const tabId = sender.tab?.id ?? message.tabId;
                    if (tabId != null) await chrome.tabs.sendMessage(tabId, message.message).catch(() => {});
                    sendResponse({ ok: true });
                    return;
                }

                // Any frame → the panel in the top frame of the same tab.
                case 'TO_TOP': {
                    const tabId = sender.tab?.id;
                    if (tabId != null) {
                        await chrome.tabs.sendMessage(tabId, message.message, { frameId: 0 }).catch(() => {});
                    }
                    sendResponse({ ok: true });
                    return;
                }

                default:
                    sendResponse({ ok: false, reason: 'unknown-message' });
            }
        } catch (error) {
            console.error('[cy-td1] service worker error', error);
            sendResponse({ ok: false, reason: String(error?.message || error) });
        }
    })();
    return true; // async sendResponse
});
