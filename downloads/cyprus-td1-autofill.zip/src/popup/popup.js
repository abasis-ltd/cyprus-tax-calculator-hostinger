/**
 * Popup: what the extension currently holds, plus a manual paste route for when the
 * calculator page could not reach the content script.
 *
 * Everything the popup shows comes from chrome.storage via the service worker; the
 * popup itself stores nothing.
 */
'use strict';

const $ = (id) => document.getElementById(id);

const ask = (message) => new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) resolve({ ok: false, reason: chrome.runtime.lastError.message });
        else resolve(response ?? { ok: false, reason: 'no-response' });
    });
});

function describeAge(iso) {
    if (!iso) return '';
    const minutes = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
    if (minutes < 1) return 'just now';
    if (minutes < 60) return `${minutes} min ago`;
    const hours = Math.round(minutes / 60);
    if (hours < 24) return `${hours} h ago`;
    return `${Math.round(hours / 24)} d ago`;
}

async function render() {
    const state = await ask({ type: 'GET_STATE' });
    const statusText = $('status-text');

    if (!state.ok || !state.payload) {
        statusText.textContent = 'No figures loaded yet. Send them from the calculator’s declaration page.';
    } else {
        const { payload } = state;
        const filledCount = Object.keys(state.filled || {}).length;
        statusText.textContent =
            `${payload.items.length} figures for tax year ${payload.taxYear}, received ${describeAge(state.receivedAt)}. `
            + `${filledCount} filled so far.`;
    }

    const list = $('origins');
    list.textContent = '';
    const maps = state.maps || {};
    const origins = Object.keys(maps).filter((origin) => Object.keys(maps[origin]).length);
    if (!origins.length) {
        const li = document.createElement('li');
        li.textContent = 'No fields bound yet.';
        list.appendChild(li);
    } else {
        for (const origin of origins) {
            const li = document.createElement('li');
            const name = document.createElement('span');
            name.textContent = origin;
            const count = document.createElement('span');
            count.className = 'ok';
            count.textContent = `${Object.keys(maps[origin]).length} fields`;
            li.append(name, count);
            list.appendChild(li);
        }
    }
}

$('paste-save').addEventListener('click', async () => {
    const result = $('paste-result');
    let payload;
    try {
        payload = JSON.parse($('paste').value);
    } catch {
        result.textContent = 'That is not valid JSON.';
        return;
    }
    const response = await ask({ type: 'STORE_PAYLOAD', payload });
    result.textContent = response.ok
        ? `Loaded ${response.count} figures.`
        : `Rejected: ${response.reason}`;
    if (response.ok) {
        $('paste').value = '';
        await render();
    }
});

$('clear-payload').addEventListener('click', async () => {
    await ask({ type: 'CLEAR_ALL' });
    await render();
});

render();
