/**
 * Popup: what the extension currently holds, plus a manual paste route for when the
 * calculator page could not reach the content script.
 *
 * Everything the popup shows comes from chrome.storage via the service worker; the
 * popup itself stores nothing.
 */
'use strict';

const $ = (id) => document.getElementById(id);

const ask = (message) => new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) resolve({ ok: false, reason: chrome.runtime.lastError.message });
        else resolve(response ?? { ok: false, reason: 'no-response' });
    });
});

function describeAge(iso) {
    if (!iso) return '';
    const minutes = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
    if (minutes < 1) return 'just now';
    if (minutes < 60) return `${minutes} min ago`;
    const hours = Math.round(minutes / 60);
    if (hours < 24) return `${hours} h ago`;
    return `${Math.round(hours / 24)} d ago`;
}

async function render() {
    const state = await ask({ type: 'GET_STATE' });
    const statusText = $('status-text');

    if (!state.ok || !state.payload) {
        statusText.textContent = 'No figures loaded yet. Send them from TaxEndaxi or the calculator’s declaration page.';
    } else {
        const { payload } = state;
        const filledCount = Object.keys(state.filled || {}).length;
        statusText.textContent =
            `${payload.items.length} figures for tax year ${payload.taxYear}, received ${describeAge(state.receivedAt)}. `
            + `${filledCount} filled so far.`;
    }

    const list = $('origins');
    list.textContent = '';
    const maps = state.maps || {};
    const origins = Object.keys(maps).filter((origin) => Object.keys(maps[origin]).length);
    if (!origins.length) {
        const li = document.createElement('li');
        li.textContent = 'No fields bound yet.';
        list.appendChild(li);
    } else {
        for (const origin of origins) {
            const li = document.createElement('li');
            const name = document.createElement('span');
            name.textContent = origin;
            const count = document.createElement('span');
            count.className = 'ok';
            count.textContent = `${Object.keys(maps[origin]).length} fields`;
            li.append(name, count);
            list.appendChild(li);
        }
    }
}

$('paste-save').addEventListener('click', async () => {
    const result = $('paste-result');
    let payload;
    try {
        payload = JSON.parse($('paste').value);
    } catch {
        result.textContent = 'That is not valid JSON.';
        return;
    }
    // A saved copy of the return ("Save a copy" on TaxEndaxi) is JSON too, and the one
    // people find first. It holds the answers, not the figures TAXISnet takes, so say
    // where the right JSON comes from instead of a bare "wrong-source".
    if (payload && typeof payload === 'object' && payload.kind === 'cy-tax-declaration-draft') {
        result.textContent = 'This is a saved copy of your return, not the figures for TAXISnet. '
            + 'Open it on TaxEndaxi and press “Send to the browser extension” at the end of the return. '
            + 'If the page cannot reach the extension, that button copies the right JSON to paste here.';
        return;
    }
    const response = await ask({ type: 'STORE_PAYLOAD', payload });
    result.textContent = response.ok
        ? `Loaded ${response.count} figures.`
        : response.reason === 'wrong-source'
            ? 'Rejected: this JSON did not come from the “Send to the browser extension” button on TaxEndaxi.'
            : `Rejected: ${response.reason}`;
    if (response.ok) {
        $('paste').value = '';
        await render();
    }
});

$('clear-payload').addEventListener('click', async () => {
    await ask({ type: 'CLEAR_ALL' });
    await render();
});

/** The portal panel's visibility. "Hide" on the panel removes it outright; this is the way back. */
async function renderPanelToggle() {
    const { panelHidden } = await chrome.storage.local.get('panelHidden');
    $('panel-toggle').textContent = panelHidden ? 'Show panel on the return' : 'Hide panel';
    $('panel-hint').textContent = panelHidden
        ? 'The panel is hidden on TAXISnet pages.'
        : 'The panel shows on the TAXISnet return. It is never printed.';
}

$('panel-toggle').addEventListener('click', async () => {
    const { panelHidden } = await chrome.storage.local.get('panelHidden');
    await chrome.storage.local.set({ panelHidden: !panelHidden });
    await renderPanelToggle();
});

render();
renderPanelToggle();
