/**
 * The calculator side of the hand-off.
 *
 * Runs on cyprustaxcalculator.abasis.ai (and localhost during development) and does
 * exactly one thing: relay a same-origin `window.postMessage` from the page into the
 * extension's storage. It reads nothing else from the page and sends nothing to any
 * server.
 *
 * Counterpart: src/extensionBridge.ts in the calculator.
 */
(() => {
    'use strict';

    const PAGE_SOURCE = 'cy-td1-page';
    const EXT_SOURCE = 'cy-td1-extension';

    const reply = (type, extra = {}) => {
        window.postMessage({ source: EXT_SOURCE, type, ...extra }, window.location.origin);
    };

    // Reloading an unpacked extension invalidates the API object held by content
    // scripts in tabs that were already open. Such a script must not answer PING:
    // doing so tells the calculator it can accept a payload, then sendMessage throws
    // "Extension context invalidated". A page refresh creates a live context again.
    const runtimeReady = () => {
        try {
            return typeof chrome !== 'undefined' && Boolean(chrome.runtime?.id);
        } catch {
            return false;
        }
    };

    const rejectionReason = (error) => {
        try {
            return error?.message || String(error || 'extension-context-invalidated');
        } catch {
            return 'extension-context-invalidated';
        }
    };

    window.addEventListener('message', (event) => {
        // Only messages this page posted to itself. Anything from an iframe or another
        // origin is ignored: a payload is the taxpayer's own figures, and no third
        // party gets to put figures into their tax return.
        if (event.source !== window) return;
        if (event.origin !== window.location.origin) return;

        const data = event.data;
        if (!data || data.source !== PAGE_SOURCE) return;

        if (data.type === 'PING') {
            if (runtimeReady()) reply('READY');
            return;
        }

        if (data.type !== 'PAYLOAD') return;

        if (!runtimeReady()) {
            reply('PAYLOAD_REJECTED', { reason: 'extension-context-invalidated' });
            return;
        }
        try {
            chrome.runtime.sendMessage({ type: 'STORE_PAYLOAD', payload: data.payload }, (response) => {
                try {
                    if (chrome.runtime.lastError) {
                        reply('PAYLOAD_REJECTED', { reason: chrome.runtime.lastError.message });
                        return;
                    }
                    if (response?.ok) reply('PAYLOAD_STORED', { count: response.count });
                    else reply('PAYLOAD_REJECTED', { reason: response?.reason ?? 'unknown' });
                } catch (error) {
                    reply('PAYLOAD_REJECTED', { reason: rejectionReason(error) });
                }
            });
        } catch (error) {
            reply('PAYLOAD_REJECTED', { reason: rejectionReason(error) });
        }
    });

    // The page may be listening before this script ran, or after — announce either way.
    if (runtimeReady()) reply('READY');
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            if (runtimeReady()) reply('READY');
        }, { once: true });
    }
})();
