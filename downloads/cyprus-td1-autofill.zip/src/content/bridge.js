/**
 * The calculator side of the hand-off.
 *
 * Runs on cyprustaxcalculator.abasis.ai (and localhost during development) and does
 * exactly one thing: relay a same-origin `window.postMessage` from the page into the
 * extension's storage. It reads nothing else from the page and sends nothing to any
 * server.
 *
 * Counterpart: src/extensionBridge.ts in the calculator.
 */
(() => {
    'use strict';

    const PAGE_SOURCE = 'cy-td1-page';
    const EXT_SOURCE = 'cy-td1-extension';

    const reply = (type, extra = {}) => {
        window.postMessage({ source: EXT_SOURCE, type, ...extra }, window.location.origin);
    };

    window.addEventListener('message', (event) => {
        // Only messages this page posted to itself. Anything from an iframe or another
        // origin is ignored: a payload is the taxpayer's own figures, and no third
        // party gets to put figures into their tax return.
        if (event.source !== window) return;
        if (event.origin !== window.location.origin) return;

        const data = event.data;
        if (!data || data.source !== PAGE_SOURCE) return;

        if (data.type === 'PING') {
            reply('READY');
            return;
        }

        if (data.type !== 'PAYLOAD') return;

        chrome.runtime.sendMessage({ type: 'STORE_PAYLOAD', payload: data.payload }, (response) => {
            if (chrome.runtime.lastError) {
                reply('PAYLOAD_REJECTED', { reason: chrome.runtime.lastError.message });
                return;
            }
            if (response?.ok) reply('PAYLOAD_STORED', { count: response.count });
            else reply('PAYLOAD_REJECTED', { reason: response?.reason ?? 'unknown' });
        });
    });

    // The page may be listening before this script ran, or after — announce either way.
    reply('READY');
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => reply('READY'), { once: true });
    }
})();
