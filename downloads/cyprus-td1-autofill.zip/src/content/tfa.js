/**
 * The portal side: a panel listing every TD.1 figure, one "bind" and one "fill"
 * per figure.
 *
 * Why binding rather than a shipped list of selectors: the return lives behind CY
 * Login, so its markup can't be mapped in advance, and the portal it lives on changes
 * with the tax year — TAXISnet for the 2025 return, Tax For All from 2026. The user
 * teaches the extension where each figure goes once; the binding is stored per origin
 * and reused on later visits (see shared/locator.js for how a binding survives a
 * reload). Nothing here is specific to either portal.
 *
 * Two hard rules, enforced below rather than documented:
 *   - the extension writes to input/select/textarea only, never clicks a page control,
 *     and has no code path that submits the return;
 *   - nothing is written without the user pressing "fill" for that specific figure.
 *
 * Runs in every frame. The panel only renders in the top frame; other frames just
 * listen for pick and fill requests, because the form may be inside an iframe.
 */
(() => {
    'use strict';

    const PANEL_ID = 'cy-td1-autofill-panel';
    const ERROR_PAGE = /\/epr1\/errorsEPR1MLookup\.do$/i;
    // The errors lookup is a small read-only popup. A form panel cannot do useful
    // work there and only obscures the validation messages.
    if (ERROR_PAGE.test(location.pathname)) {
        document.getElementById(PANEL_ID)?.remove();
        return;
    }

    const L = globalThis.CyTd1Locator;
    if (!L) return;

    const isTop = window.top === window;

    // Payloads already stored by an older calculator keep their original order. Sort
    // in the panel too, so updating only the unpacked extension immediately fixes an
    // existing hand-off rather than requiring a site deployment and another send.
    const PORTAL_REF_ORDER = [
        'PART 1', 'PART 2',
        'PART 3 · A', 'PART 3 · B1', 'PART 3 · B2', 'PART 3 · B3', 'PART 3',
        'PART 4 · A1', 'PART 4 · A2', 'PART 4 · A3',
        'PART 4 · B1', 'PART 4 · B2', 'PART 4 · C', 'PART 4 · D',
        'PART 4 · E', 'PART 4 · F', 'PART 4 · G', 'PART 4 · H',
        'PART 4 · I', 'PART 4 · J', 'PART 4',
        'PART 5 · A', 'PART 5 · B', 'PART 5 · C', 'PART 5',
        'PART 6', 'PART 7', 'PART 8',
        'SELF ASSESSMENT', 'SDC CALCULATION', 'GHS', 'TAX CALCULATION',
    ];

    function orderItems(items) {
        const rank = (ref) => {
            const index = PORTAL_REF_ORDER.findIndex((prefix) => ref === prefix || ref.startsWith(`${prefix} ·`));
            return index < 0 ? PORTAL_REF_ORDER.length : index;
        };
        return items.map((item, index) => ({ item, index }))
            .sort((a, b) => rank(a.item.ref) - rank(b.item.ref) || a.index - b.index)
            .map(({ item }) => item);
    }

    /* ------------------------------------------------------------------ *
     * Frame-local pick mode
     * ------------------------------------------------------------------ */

    let picking = null;      // { itemId } while the user is choosing a field
    let hovered = null;

    const clearHover = () => {
        if (hovered) hovered.style.removeProperty('box-shadow');
        hovered = null;
    };

    function onPickMove(event) {
        const target = L.toFillableTarget(event.composedPath?.()[0] || event.target);
        if (target === hovered) return;
        clearHover();
        if (target) {
            hovered = target;
            hovered.style.boxShadow = '0 0 0 3px #4f46e5';
        }
    }

    function onPickClick(event) {
        const target = L.toFillableTarget(event.composedPath?.()[0] || event.target);
        // Swallow the click either way: on the portal a stray click can trigger
        // navigation, and the user is in "point at a field" mode, not using the form.
        event.preventDefault();
        event.stopPropagation();

        const itemId = picking?.itemId;
        stopPick();
        if (!itemId) return;

        if (!target) {
            sendToTop({ type: 'BIND_RESULT', itemId, ok: false, reason: 'not-a-field' });
            return;
        }
        const descriptor = L.describe(target);
        sendToTop({
            type: 'BIND_RESULT',
            itemId,
            ok: !!descriptor,
            reason: descriptor ? undefined : 'not-describable',
            descriptor,
        });
    }

    function onPickKey(event) {
        if (event.key !== 'Escape') return;
        const itemId = picking?.itemId;
        stopPick();
        if (itemId) sendToTop({ type: 'BIND_RESULT', itemId, ok: false, reason: 'cancelled' });
    }

    function startPick(itemId) {
        stopPick();
        picking = { itemId };
        document.addEventListener('mousemove', onPickMove, true);
        document.addEventListener('click', onPickClick, true);
        document.addEventListener('keydown', onPickKey, true);
        document.body?.style.setProperty('cursor', 'crosshair', 'important');
    }

    function stopPick() {
        if (!picking) return;
        picking = null;
        clearHover();
        document.removeEventListener('mousemove', onPickMove, true);
        document.removeEventListener('click', onPickClick, true);
        document.removeEventListener('keydown', onPickKey, true);
        document.body?.style.removeProperty('cursor');
    }

    /* ------------------------------------------------------------------ *
     * Messaging helpers
     * ------------------------------------------------------------------ */

    const sendToTop = (message) => chrome.runtime.sendMessage({ type: 'TO_TOP', message }).catch(() => {});
    // An older calculator sent amounts with a dot and 5C "Amount paid" with cents; the
    // portal rejects both. Rewrite them here, like the ordering above, so a stored
    // hand-off is fixed without another send.
    const WHOLE_EURO_TARGET = /^fld5D[12]_7_\d+$/;
    function forPortal(payload) {
        if (!payload?.items || location.hostname !== 'taxisnet.mof.gov.cy') return payload;
        return {
            ...payload,
            items: payload.items.map((item) => {
                if (item.kind !== 'amount') return item;
                const target = item.targetId ?? String(item.id).replace(/^portal\./, '');
                return { ...item, value: L.taxisnetAmount(item.value, WHOLE_EURO_TARGET.test(target)) };
            }),
        };
    }

    const broadcast = (message) => chrome.runtime.sendMessage({ type: 'BROADCAST', message }).catch(() => {});
    const ask = (message) => chrome.runtime.sendMessage(message).catch(() => ({ ok: false }));

    // The year shown by the portal is authoritative. A stored binding is not proof
    // that a different year's return has the same meaning or field layout.
    // The employee return is headed "DECLARATION OF INCOME", the self-employed one
    // "INCOME TAX RETURN self - employed" (read live on 25 Sep 2026).
    const RETURN_HEADING = /DECLARATION OF INCOME|INCOME TAX RETURN/i;
    const yearMatches = (year) => location.hostname === 'taxisnet.mof.gov.cy'
        ? year === 2025 && /(?:DECLARATION OF INCOME|INCOME TAX RETURN)[\s\S]{0,160}\b2025\b/i.test(document.body.innerText)
        : false;

    chrome.runtime.onMessage.addListener((message) => {
        if (!message || typeof message !== 'object') return;

        switch (message.type) {
            case 'PICK_START':
                startPick(message.itemId);
                break;

            case 'PICK_CANCEL':
                stopPick();
                break;

            case 'FILL_REQUEST': {
                if (!yearMatches(message.taxYear)) return;
                const el = L.resolve(message.descriptor, document);
                if (!el) return;             // another frame probably has it
                L.highlight(el);
                const outcome = L.fill(el, message.value);
                sendToTop({ type: 'FILL_RESULT', itemId: message.itemId, ...outcome });
                break;
            }

            case 'LOCATE_REQUEST': {
                const el = L.resolve(message.descriptor, document);
                if (!el) return;
                L.highlight(el);
                sendToTop({ type: 'LOCATE_RESULT', itemId: message.itemId, ok: true });
                break;
            }

            // Handled by the panel; ignored in subframes.
            case 'BIND_RESULT':
            case 'FILL_RESULT':
            case 'LOCATE_RESULT':
                if (isTop) panel?.onFrameMessage(message);
                break;

            default:
                break;
        }
    });

    if (!isTop) return;

    // The payment gateway, the returns list and the TOTALS confirmation are all on
    // mof.gov.cy too. The panel belongs on the return itself and nowhere else.
    const isReturnPage = () => RETURN_HEADING.test(document.body?.innerText ?? '');
    if (!isReturnPage()) return;

    /* ------------------------------------------------------------------ *
     * Panel (top frame only)
     * ------------------------------------------------------------------ */

    const TEXT = {
        en: {
            title: 'TD.1 Autofill', manualOnly: 'Manual transfer: check the exact destination against the TAXISnet guide.', wrongYear: 'Open the matching TAXISnet 2025 return in English. Tax For All mapping is not verified.', empty: 'No figures yet. Open the calculator’s declaration page and press “Send to the browser extension”.',
            bind: 'Bind', rebind: 'Rebind', fill: 'Fill', copy: 'Copy', locate: 'Show',
            fillVisible: 'Fill available', fillVisibleConfirm: 'Fill all {count} supported fields available on this screen? Existing values in those fields will be replaced. Nothing will be submitted.',
            fillVisibleResult: 'Filled {filled} fields on this screen; {failed} were refused.', noneVisible: 'No supported fields from the list are available on this screen.',
            unbound: 'not bound', bound: 'bound', filled: 'filled', notFound: 'field not found — rebind', notOnForm: 'not on this form — type it by hand',
            picking: 'Click the field on the page. Esc to cancel.', copied: 'Copied',
            hide: 'Hide', exportMap: 'Export bindings', clearMap: 'Forget bindings',
            footer: 'The extension never presses Submit. Check every figure against your documents before you file.',
            year: 'Tax year', of: 'of', done: 'filled',
            confirmClear: 'Forget all field bindings for this site?',
        },
        ru: {
            title: 'Автозаполнение TD.1', manualOnly: 'Ручной перенос: сверьте точное поле с руководством TAXISnet.', wrongYear: 'Откройте декларацию TAXISnet 2025 на английском. Карта Tax For All пока не проверена.', empty: 'Данных пока нет. Откройте страницу декларации в калькуляторе и нажмите «Отправить в расширение браузера».',
            bind: 'Привязать', rebind: 'Перепривязать', fill: 'Заполнить', copy: 'Копировать', locate: 'Показать',
            fillVisible: 'Заполнить доступные', fillVisibleConfirm: 'Заполнить все доступные на этом экране поддерживаемые поля ({count})? Их текущие значения будут заменены. Декларация не будет отправлена.',
            fillVisibleResult: 'На этом экране заполнено полей: {filled}; отклонено: {failed}.', noneVisible: 'На этом экране нет доступных поддерживаемых полей из списка.',
            unbound: 'не привязано', bound: 'привязано', filled: 'заполнено', notFound: 'поле не найдено — привяжите заново', notOnForm: 'на этой форме такого поля нет — введите вручную',
            picking: 'Кликните по полю на странице. Esc — отмена.', copied: 'Скопировано',
            hide: 'Скрыть', exportMap: 'Выгрузить привязки', clearMap: 'Забыть привязки',
            footer: 'Расширение никогда не нажимает «Отправить». Сверьте каждую цифру с документами перед подачей.',
            year: 'Налоговый год', of: 'из', done: 'заполнено',
            confirmClear: 'Забыть все привязки полей для этого сайта?',
        },
        el: {
            title: 'Αυτόματη συμπλήρωση TD.1', manualOnly: 'Χειροκίνητη μεταφορά: ελέγξτε το πεδίο με τον οδηγό TAXISnet.', wrongYear: 'Ανοίξτε τη δήλωση TAXISnet 2025 στα αγγλικά. Η αντιστοίχιση Tax For All δεν έχει ελεγχθεί.', empty: 'Δεν υπάρχουν ακόμη ποσά. Ανοίξτε τη σελίδα δήλωσης στον υπολογιστή φόρου και πατήστε «Αποστολή στην επέκταση».',
            bind: 'Σύνδεση', rebind: 'Επανασύνδεση', fill: 'Συμπλήρωση', copy: 'Αντιγραφή', locate: 'Εμφάνιση',
            fillVisible: 'Συμπλήρωση διαθέσιμων', fillVisibleConfirm: 'Να συμπληρωθούν και τα {count} υποστηριζόμενα πεδία που είναι διαθέσιμα σε αυτή την οθόνη; Οι υπάρχουσες τιμές τους θα αντικατασταθούν. Η δήλωση δεν θα υποβληθεί.',
            fillVisibleResult: 'Συμπληρώθηκαν {filled} πεδία σε αυτή την οθόνη· απορρίφθηκαν {failed}.', noneVisible: 'Δεν υπάρχουν διαθέσιμα υποστηριζόμενα πεδία από τη λίστα σε αυτή την οθόνη.',
            unbound: 'χωρίς σύνδεση', bound: 'συνδεδεμένο', filled: 'συμπληρώθηκε', notFound: 'το πεδίο δεν βρέθηκε — συνδέστε ξανά', notOnForm: 'δεν υπάρχει σε αυτό το έντυπο — πληκτρολογήστε το',
            picking: 'Κάντε κλικ στο πεδίο. Esc για ακύρωση.', copied: 'Αντιγράφηκε',
            hide: 'Απόκρυψη', exportMap: 'Εξαγωγή συνδέσεων', clearMap: 'Διαγραφή συνδέσεων',
            footer: 'Η επέκταση δεν πατά ποτέ «Υποβολή». Ελέγξτε κάθε ποσό πριν την υποβολή.',
            year: 'Φορολογικό έτος', of: 'από', done: 'συμπληρώθηκαν',
            confirmClear: 'Διαγραφή όλων των συνδέσεων πεδίων για αυτόν τον ιστότοπο;',
        },
    };

    const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => (
        { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
    ));

    const PANEL_CSS = `
        :host { all: initial; }
        .wrap {
            position: fixed; top: 16px; right: 16px; z-index: 2147483647;
            width: 360px; max-height: 78vh; display: flex; flex-direction: column;
            font: 13px/1.45 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            color: #0f172a; background: #fff;
            border: 1px solid #cbd5e1; border-radius: 12px;
            box-shadow: 0 10px 40px rgba(15, 23, 42, .22);
        }
        /* The return is printed from the same page; the panel must never reach paper. */
        @media print { :host { display: none !important; } }
        header { display: flex; align-items: center; gap: 8px; padding: 10px 12px; border-bottom: 1px solid #e2e8f0; }
        header h1 { margin: 0; font-size: 13px; font-weight: 700; flex: 1; }
        .meta { font-size: 11px; color: #64748b; }
        button {
            font: inherit; font-size: 11px; font-weight: 600; cursor: pointer;
            padding: 3px 8px; border-radius: 6px; border: 1px solid #cbd5e1;
            background: #f8fafc; color: #0f172a;
        }
        button:hover { border-color: #4f46e5; color: #4f46e5; }
        button.primary { background: #4f46e5; border-color: #4f46e5; color: #fff; }
        button.primary:hover { background: #4338ca; color: #fff; }
        .banner { padding: 7px 12px; background: #eef2ff; color: #3730a3; font-size: 12px; font-weight: 600; }
        .list { overflow-y: auto; padding: 4px 0; flex: 1; }
        .section { padding: 8px 12px 2px; font-size: 11px; font-weight: 700; text-transform: uppercase;
                   letter-spacing: .04em; color: #64748b; }
        .row { padding: 7px 12px; border-top: 1px solid #f1f5f9; display: grid; gap: 4px; }
        .row.is-filled { background: #f0fdf4; }
        .row-top { display: flex; align-items: baseline; gap: 8px; }
        .label { flex: 1; min-width: 0; }
        .value { font-variant-numeric: tabular-nums; font-weight: 700; white-space: nowrap; }
        .ref { font: 11px/1.3 ui-monospace, SFMono-Regular, Menlo, monospace; color: #64748b; }
        .note { font-size: 11px; color: #475569; }
        .code { display: inline-block; margin-left: 6px; padding: 0 5px; border-radius: 4px;
                background: #eef2ff; color: #3730a3; font-size: 10px; font-weight: 700; }
        .status { font-size: 11px; font-weight: 600; }
        .status.unbound { color: #b45309; }
        .status.bound { color: #475569; }
        .status.filled { color: #15803d; }
        .status.error { color: #be123c; }
        .actions { display: flex; gap: 6px; flex-wrap: wrap; }
        footer { padding: 8px 12px; border-top: 1px solid #e2e8f0; font-size: 11px; color: #64748b; }
        .footer-actions { display: flex; gap: 6px; margin-bottom: 6px; }
        @media (prefers-color-scheme: dark) {
            .wrap { background: #0f172a; color: #e2e8f0; border-color: #334155; }
            header, .row, footer { border-color: #1e293b; }
            .section, .meta, .ref, footer { color: #94a3b8; }
            .note { color: #cbd5e1; }
            button { background: #1e293b; border-color: #334155; color: #e2e8f0; }
            .banner { background: #1e1b4b; color: #c7d2fe; }
            .row.is-filled { background: #052e16; }
        }
    `;

    const panel = (() => {
        let host = null;
        let root = null;
        let state = { payload: null, map: {}, filled: {}, picking: null, flash: {}, bulkMessage: '' };

        const t = (key) => (TEXT[state.payload?.lang?.slice(0, 2)] || TEXT.en)[key];
        const format = (key, values) => Object.entries(values).reduce(
            (text, [name, value]) => text.replace(`{${name}}`, String(value)), t(key));

        async function refresh() {
            const response = await ask({ type: 'GET_STATE', origin: location.origin });
            if (!response?.ok) return;
            state = { ...state, payload: forPortal(response.payload), map: response.map || {}, filled: response.filled || {} };
            render();
        }

        const descriptorFor = (item) => item.targetId ? { exactId: item.targetId } : state.map[item.id];
        // A calculator field the self-employed form does not have: said on the row itself.
        const offForm = (item) => Boolean(item.targetId) && L.targetFor(item.targetId) === null;

        function statusOf(item) {
            if (state.flash[item.id]) return { cls: 'error', text: state.flash[item.id] };
            if (offForm(item)) return { cls: 'unbound', text: t('notOnForm') };
            if (state.filled[item.id]) return { cls: 'filled', text: `${t('filled')}: ${state.filled[item.id].written}` };
            if (descriptorFor(item)) return { cls: 'bound', text: t('bound') };
            return { cls: 'unbound', text: t('unbound') };
        }

        function rowHtml(item) {
            const status = statusOf(item);
            const bound = !item.manualOnly && !!descriptorFor(item);
            return `
                <div class="row ${state.filled[item.id] ? 'is-filled' : ''}">
                    <div class="row-top">
                        <span class="label">${esc(item.label)}${item.code ? `<span class="code">${esc(item.code)}</span>` : ''}</span>
                        <span class="value">${item.negative ? '−' : ''}${esc(item.value)}</span>
                    </div>
                    <div class="ref">${esc(item.ref)}</div>
                    ${item.manualOnly ? `<div class="note">${esc(t('manualOnly'))}</div>` : ''}
                    ${item.note ? `<div class="note">${esc(item.note)}</div>` : ''}
                    <div class="row-top">
                        <span class="status ${status.cls} label">${esc(status.text)}</span>
                        <span class="actions">
                            <button data-action="copy" data-id="${esc(item.id)}">${esc(t('copy'))}</button>
                            ${bound ? `<button data-action="locate" data-id="${esc(item.id)}">${esc(t('locate'))}</button>` : ''}
                            ${item.targetId || item.manualOnly ? '' : `<button data-action="bind" data-id="${esc(item.id)}">${esc(bound ? t('rebind') : t('bind'))}</button>`}
                            ${bound ? `<button class="primary" data-action="fill" data-id="${esc(item.id)}">${esc(t('fill'))}</button>` : ''}
                        </span>
                    </div>
                </div>`;
        }

        function render() {
            if (!root) return;
            const items = orderItems(state.payload?.items ?? []);
            const writableItems = items.filter((item) => !item.manualOnly);
            const filledCount = writableItems.filter((item) => state.filled[item.id]).length;

            let body;
            if (!items.length) {
                body = `<div class="row"><div class="note">${esc(t('empty'))}</div></div>`;
            } else {
                const chunks = [];
                let currentSection = null;
                for (const item of items) {
                    if (item.section !== currentSection) {
                        currentSection = item.section;
                        chunks.push(`<div class="section">${esc(currentSection)}</div>`);
                    }
                    chunks.push(rowHtml(item));
                }
                body = chunks.join('');
            }

            root.innerHTML = `
                <style>${PANEL_CSS}</style>
                <div class="wrap">
                    <header>
                        <h1>${esc(t('title'))}</h1>
                        <span class="meta">${filledCount} ${esc(t('of'))} ${writableItems.length} ${esc(t('done'))}</span>
                        <button data-action="hide">${esc(t('hide'))}</button>
                    </header>
                    ${state.picking || state.bulkMessage ? `<div class="banner">${esc(state.picking ? t('picking') : state.bulkMessage)}</div>` : ''}
                    <div class="list">${body}${(state.payload?.checks ?? []).map(check => `<div class="row note">${esc(check)}</div>`).join('')}</div>
                    <footer>
                        <div class="footer-actions">
                            ${items.length ? `<button class="primary" data-action="fill-visible">${esc(t('fillVisible'))}</button>` : ''}
                            <button data-action="export">${esc(t('exportMap'))}</button>
                            <button data-action="clear-map">${esc(t('clearMap'))}</button>
                        </div>
                        ${esc(t('footer'))}
                    </footer>
                </div>`;
        }

        function flash(itemId, text) {
            state.flash = { ...state.flash, [itemId]: text };
            render();
            setTimeout(() => {
                const { [itemId]: _dropped, ...rest } = state.flash;
                state.flash = rest;
                render();
            }, 2500);
        }

        const itemById = (id) => state.payload?.items.find((item) => item.id === id) || null;

        async function onClick(event) {
            const button = event.target.closest?.('button[data-action]');
            if (!button) return;
            const { action, id } = button.dataset;

            if (action === 'hide') {
                // Hidden means gone: the toolbar popup is the only way back. Stored,
                // because every part of the return is a fresh page load.
                await chrome.storage.local.set({ panelHidden: true }).catch(() => {});
                unmount();
                return;
            }

            if (action === 'export') {
                const response = await ask({ type: 'GET_STATE', origin: location.origin });
                const blob = new Blob([JSON.stringify(response?.map ?? {}, null, 2)], { type: 'application/json' });
                const link = document.createElement('a');
                link.href = URL.createObjectURL(blob);
                link.download = `td1-bindings-${location.hostname}.json`;
                link.click();
                setTimeout(() => URL.revokeObjectURL(link.href), 5000);
                return;
            }

            if (action === 'clear-map') {
                if (!confirm(t('confirmClear'))) return;
                await ask({ type: 'CLEAR_MAP', origin: location.origin });
                await refresh();
                return;
            }

            if (action === 'fill-visible') {
                if (!yearMatches(state.payload?.taxYear)) {
                    state.bulkMessage = t('wrongYear');
                    render();
                    return;
                }
                const available = (state.payload?.items ?? []).flatMap((item) => {
                    if (item.manualOnly) return [];
                    const descriptor = descriptorFor(item);
                    const target = descriptor ? L.resolve(descriptor, document) : null;
                    if (!target || !target.getClientRects().length) return [];
                    return [{ item, target }];
                });
                if (!available.length) {
                    state.bulkMessage = t('noneVisible');
                    render();
                    return;
                }
                if (!confirm(format('fillVisibleConfirm', { count: available.length }))) return;
                let filled = 0;
                let failed = 0;
                for (const { item, target } of available) {
                    const outcome = L.fill(target, item.value);
                    if (outcome.ok) {
                        await ask({ type: 'MARK_FILLED', itemId: item.id, written: outcome.written });
                        filled += 1;
                    } else {
                        failed += 1;
                    }
                }
                state.bulkMessage = format('fillVisibleResult', { filled, failed });
                await refresh();
                setTimeout(() => {
                    state.bulkMessage = '';
                    render();
                }, 4000);
                return;
            }

            const item = itemById(id);
            if (!item) return;

            if (action === 'copy') {
                await navigator.clipboard.writeText(item.value).catch(() => {});
                flash(id, t('copied'));
                return;
            }
            if (item.manualOnly) return;

            if (action === 'bind') {
                state.picking = id;
                render();
                startPick(id);                              // this frame
                broadcast({ type: 'PICK_START', itemId: id }); // and every other frame
                return;
            }

            const descriptor = descriptorFor(item);
            if (!descriptor) return;
            if (offForm(item)) {
                flash(id, t('notOnForm'));
                return;
            }

            if (action === 'locate' || action === 'fill') {
                if (action === 'fill' && !yearMatches(state.payload?.taxYear)) {
                    flash(id, t('wrongYear'));
                    return;
                }
                const local = L.resolve(descriptor, document);
                if (local) {
                    L.highlight(local);
                    if (action === 'fill') {
                        const outcome = L.fill(local, item.value);
                        await onFrameMessage({ type: 'FILL_RESULT', itemId: id, ...outcome });
                    }
                    return;
                }
                // Not in the top document — the form is probably in an iframe.
                broadcast(action === 'fill'
                    ? { type: 'FILL_REQUEST', itemId: id, descriptor, value: item.value, taxYear: state.payload?.taxYear }
                    : { type: 'LOCATE_REQUEST', itemId: id, descriptor });
                const pending = id;
                setTimeout(() => {
                    if (!state.filled[pending] && action === 'fill') flash(pending, t('notFound'));
                }, 1500);
            }
        }

        async function onFrameMessage(message) {
            if (message.type === 'BIND_RESULT') {
                state.picking = null;
                stopPick();
                broadcast({ type: 'PICK_CANCEL' });
                if (message.ok && message.descriptor) {
                    await ask({
                        type: 'SAVE_BINDING',
                        origin: location.origin,
                        itemId: message.itemId,
                        descriptor: message.descriptor,
                    });
                    await refresh();
                } else {
                    render();
                    if (message.reason && message.reason !== 'cancelled') flash(message.itemId, message.reason);
                }
                return;
            }

            if (message.type === 'FILL_RESULT') {
                if (message.ok) {
                    await ask({ type: 'MARK_FILLED', itemId: message.itemId, written: message.written });
                    await refresh();
                } else {
                    flash(message.itemId, message.reason || 'error');
                }
            }
        }

        async function mount() {
            const { panelHidden } = await chrome.storage.local.get('panelHidden').catch(() => ({}));
            if (panelHidden || document.getElementById(PANEL_ID)) return;
            host = document.createElement('div');
            host.id = PANEL_ID;
            root = host.attachShadow({ mode: 'open' });
            root.addEventListener('click', onClick);
            document.documentElement.appendChild(host);
            refresh();
        }

        function unmount() {
            host?.remove();
            host = null;
            root = null;
        }

        return { mount, unmount, refresh, onFrameMessage };
    })();

    // A payload can arrive while the portal tab is already open. `filled` lives in
    // session storage, which content scripts don't observe — the panel refreshes
    // itself after each fill instead.
    chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== 'local') return;
        if (changes.panelHidden) {
            if (changes.panelHidden.newValue) panel.unmount();
            else panel.mount();
            return;
        }
        if (changes.payload || changes.maps) panel.refresh();
    });

    panel.mount();
})();
