/**
 * Finding a form field again after the page has been reloaded.
 *
 * The strategies here are portal-agnostic on purpose: the 2025 return is filed in
 * TAXISnet and later years move to Tax For All, and a binding has to survive both.
 * Some strategies only ever fire on one of them — Tax For All is a SAP UI5
 * application, whose element ids look like `__xmlview3--grossEmoluments-inner`, where
 * the `__xmlview3` prefix is a render counter that changes between visits but the part
 * after `--` is authored and stable. Nothing on either page is reliable on its own, so
 * a binding records every clue we can get and resolution tries them in order of
 * trustworthiness, accepting a strategy only when it matches exactly one element.
 *
 * Loaded as a classic content script before tfa.js — hence the global, not a module.
 */
(() => {
    'use strict';

    /** Types we will never write to, whatever the binding says. */
    const FORBIDDEN_INPUT_TYPES = new Set([
        'submit', 'button', 'reset', 'image', 'file', 'password', 'hidden', 'checkbox', 'radio',
    ]);

    const FILLABLE_SELECTOR = 'input, textarea, select, [contenteditable=""], [contenteditable="true"]';

    /** Escapes a value for use inside a quoted attribute selector. */
    const q = (value) => `"${String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`;

    const clean = (text) => (text || '').replace(/\s+/g, ' ').trim().slice(0, 160);

    function isFillable(el) {
        if (!el || el.nodeType !== 1) return false;
        if (el.disabled || el.readOnly || el.matches(':disabled') || el.getAttribute('aria-disabled') === 'true'
            || el.getAttribute('aria-readonly') === 'true') return false;
        const tag = el.tagName.toLowerCase();
        if (tag === 'input') return !FORBIDDEN_INPUT_TYPES.has((el.type || 'text').toLowerCase());
        if (tag === 'textarea' || tag === 'select') return true;
        return el.isContentEditable === true;
    }

    /**
     * UI5 renders a styled wrapper around a real <input>; a click usually lands on the
     * wrapper. Walk down to the thing that actually holds a value.
     */
    function toFillableTarget(el) {
        if (!el) return null;
        if (isFillable(el)) return el;
        const inner = el.querySelector?.(FILLABLE_SELECTOR);
        if (inner && isFillable(inner)) return inner;
        const ancestor = el.closest?.(FILLABLE_SELECTOR);
        return ancestor && isFillable(ancestor) ? ancestor : null;
    }

    /** The authored tail of a UI5 id: `__xmlview3--grossEmoluments-inner` → `grossEmoluments-inner`. */
    function idSuffixOf(id) {
        if (!id || !id.includes('--')) return '';
        const tail = id.slice(id.lastIndexOf('--') + 2);
        return /^[A-Za-z][\w-]*$/.test(tail) ? tail : '';
    }

    /** Ids that are pure render counters tell us nothing and change every load. */
    function isStableId(id) {
        if (!id) return false;
        if (id.includes('--')) return false;          // handled by idSuffixOf instead
        if (/^__/.test(id)) return false;             // UI5 generated
        if (/^(:r|react-|ember|mui-|radix-)/i.test(id)) return false;
        if (/\d{4,}/.test(id)) return false;          // timestamps, random ids
        return true;
    }

    /**
     * Best-effort human label. Tries the accessible name first, then the visual
     * conventions UI5 uses: a `.sapMLabel` before the field, or the first cell of the
     * table row the field sits in.
     */
    function guessLabel(el) {
        if (!el) return '';

        const ariaLabel = el.getAttribute?.('aria-label');
        if (ariaLabel) return clean(ariaLabel);

        const labelledBy = el.getAttribute?.('aria-labelledby');
        if (labelledBy) {
            const text = labelledBy.split(/\s+/)
                .map((id) => el.ownerDocument.getElementById(id)?.textContent || '')
                .join(' ');
            if (clean(text)) return clean(text);
        }

        if (el.labels && el.labels.length) return clean(el.labels[0].textContent);

        const wrappingLabel = el.closest('label');
        if (wrappingLabel) return clean(wrappingLabel.textContent);

        // UI5 puts the label in a sibling container rather than a <label for=…>.
        const sapLabel = el.closest('[class*="sapMInputBase"], [class*="sapMIBar"], div, td')
            ?.previousElementSibling?.querySelector?.('[class*="sapMLabel"], label');
        if (sapLabel) return clean(sapLabel.textContent);

        const row = el.closest('tr, [role="row"]');
        if (row) {
            const firstCell = row.querySelector('td, th, [role="gridcell"], [role="rowheader"]');
            if (firstCell && !firstCell.contains(el)) return clean(firstCell.textContent);
        }

        const placeholder = el.getAttribute?.('placeholder');
        if (placeholder) return clean(placeholder);

        return '';
    }

    /** Structural fallback: `body > div:nth-of-type(2) > … > input`. Fragile, hence last. */
    function cssPath(el) {
        const parts = [];
        let node = el;
        while (node && node.nodeType === 1 && parts.length < 12) {
            const tag = node.tagName.toLowerCase();
            if (tag === 'body' || tag === 'html') break;
            const parent = node.parentElement;
            if (!parent) break;
            const siblings = Array.from(parent.children).filter((c) => c.tagName === node.tagName);
            const index = siblings.indexOf(node) + 1;
            parts.unshift(siblings.length > 1 ? `${tag}:nth-of-type(${index})` : tag);
            node = parent;
        }
        return parts.length ? `body ${parts.join(' > ')}` : '';
    }

    /** Every fillable field on the page whose label reads exactly like this one. */
    function sameLabelFields(labelText, doc) {
        return Array.from(doc.querySelectorAll(FILLABLE_SELECTOR))
            .filter(isFillable)
            .filter((candidate) => guessLabel(candidate) === labelText);
    }

    /** The element a recorded structural path points at, or null. */
    function elementAtPath(descriptor, doc) {
        if (!descriptor.path) return null;
        try {
            const found = doc.querySelector(descriptor.path);
            return found && isFillable(found) && found.tagName.toLowerCase() === descriptor.tag
                ? found
                : null;
        } catch {
            return null; // malformed path — it identifies nothing
        }
    }

    /** Everything we know about a field, recorded when the user binds it. */
    function describe(el) {
        const target = toFillableTarget(el);
        if (!target) return null;
        const doc = target.ownerDocument;
        const labelText = guessLabel(target);

        /*
         * Where the field sat among the fields sharing its label, and how many there
         * were. The count is recorded for the same reason the index is: on its own the
         * index is a bet that nothing has moved, and the only way to check that bet
         * later is to know what it was made against.
         */
        let labelIndex = 0;
        let labelCount = 0;
        if (labelText) {
            const sameLabel = sameLabelFields(labelText, doc);
            labelCount = sameLabel.length;
            labelIndex = Math.max(0, sameLabel.indexOf(target));
        }

        return {
            tag: target.tagName.toLowerCase(),
            type: (target.getAttribute('type') || '').toLowerCase(),
            id: target.id || '',
            idSuffix: idSuffixOf(target.id),
            name: target.getAttribute('name') || '',
            ariaLabel: target.getAttribute('aria-label') || '',
            placeholder: target.getAttribute('placeholder') || '',
            labelText,
            labelIndex,
            labelCount,
            path: cssPath(target),
            frameUrl: doc.location ? doc.location.href.split('#')[0] : '',
            boundAt: new Date().toISOString(),
        };
    }

    /**
     * Walks the strategies from most to least trustworthy and returns the first that
     * identifies exactly one fillable element. Returns null when nothing is certain —
     * a wrong guess would type an amount into the wrong box, which is worse than
     * asking the user to rebind.
     *
     * "Exactly one" is the whole rule, and the awkward case is a label several fields
     * share: there the strategy has no single match to offer and can only fall back on
     * where the field sat. That is a bet on the page not having moved, so it is taken
     * only when the page can be shown not to have moved — see the branch itself.
     */
    function resolve(descriptor, doc = document) {
        if (descriptor?.exactId) {
            const matches = Array.from(doc.querySelectorAll(`[id=${q(descriptor.exactId)}]`));
            return matches.length === 1 && isFillable(matches[0]) ? matches[0] : null;
        }
        if (!descriptor) return null;

        const attempts = [];
        if (descriptor.id && isStableId(descriptor.id)) attempts.push(`[id=${q(descriptor.id)}]`);
        if (descriptor.idSuffix) attempts.push(`[id$=${q(`--${descriptor.idSuffix}`)}]`);
        if (descriptor.name) attempts.push(`[name=${q(descriptor.name)}]`);
        if (descriptor.ariaLabel) attempts.push(`[aria-label=${q(descriptor.ariaLabel)}]`);
        if (descriptor.placeholder) attempts.push(`[placeholder=${q(descriptor.placeholder)}]`);

        for (const selector of attempts) {
            let matches;
            try {
                matches = Array.from(doc.querySelectorAll(selector)).filter(isFillable);
            } catch {
                continue; // malformed selector — try the next strategy
            }
            if (matches.length === 1) return matches[0];
        }

        if (descriptor.labelText) {
            const sameLabel = sameLabelFields(descriptor.labelText, doc);
            if (sameLabel.length === 1) return sameLabel[0];
            /*
             * No field carries the label any more — the portal was switched to the other
             * language, or the wording changed. Nothing is ambiguous here, so the
             * structural path still gets its turn.
             */
            if (sameLabel.length === 0) return elementAtPath(descriptor, doc);
            /*
             * Several fields carry this label, so the only thing left to tell them apart
             * is where they sit — and where they sit is exactly what changes when the
             * portal renders one more row of a table whose every row is labelled the
             * same. Taking the stored index on its own would write the amount into the
             * neighbouring box and report it as filled, which is the one outcome this
             * whole module exists to prevent.
             *
             * So position is accepted only when two independent things still agree with
             * the moment of binding: the candidate set is the same size it was, and the
             * structural path recorded then still lands on that very element. Neither
             * check is worth much alone; together they say the page has not moved.
             *
             * When they disagree the answer is `null` and not the structural path:
             * that path is positional too, and falling through to it would reinstate the
             * guess this branch just refused. A binding made before `labelCount` was
             * recorded has nothing to check against and is treated the same way — the
             * user rebinds once, which is cheap, and no amount is misfiled meanwhile.
             */
            const byIndex = sameLabel[descriptor.labelIndex ?? 0];
            const sameShape = sameLabel.length === descriptor.labelCount;
            return byIndex && sameShape && byIndex === elementAtPath(descriptor, doc)
                ? byIndex
                : null;
        }

        return elementAtPath(descriptor, doc);
    }

    /**
     * Writes through the native value setter so React and UI5 see the change: both
     * shadow the `value` property, and assigning to it directly leaves their internal
     * state untouched, so the field visually updates and then reverts on blur.
     */
    function setNativeValue(el, value) {
        const proto = el instanceof HTMLTextAreaElement
            ? HTMLTextAreaElement.prototype
            : el instanceof HTMLSelectElement
                ? HTMLSelectElement.prototype
                : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
        if (setter) setter.call(el, value);
        else el.value = value;
    }

    function dispatch(el, ...types) {
        for (const type of types) {
            el.dispatchEvent(new Event(type, { bubbles: true, composed: true }));
        }
    }

    /** Fills one field. Returns { ok, reason?, written? }. Never clicks anything. */
    function fill(el, value) {
        if (!isFillable(el)) return { ok: false, reason: 'not-fillable' };

        const tag = el.tagName.toLowerCase();
        el.focus({ preventScroll: true });

        if (tag === 'select') {
            const wanted = String(value).trim().toLowerCase();
            const option = Array.from(el.options).find((o) =>
                o.value.trim().toLowerCase() === wanted || o.text.trim().toLowerCase() === wanted);
            if (!option || option.disabled || option.parentElement?.disabled) return { ok: false, reason: 'no-matching-option' };
            el.value = option.value;
            dispatch(el, 'input', 'change');
            el.blur();
            return el.value === option.value ? { ok: true, written: option.text } : { ok: false, reason: 'value-rejected' };
        }

        if (el.isContentEditable) {
            el.textContent = String(value);
            dispatch(el, 'input', 'change');
            el.blur();
            return { ok: true, written: String(value) };
        }

        setNativeValue(el, String(value));
        // UI5 inputs commit on `change`; `input` alone leaves the model stale.
        dispatch(el, 'input', 'change');
        el.blur();
        dispatch(el, 'blur');
        return el.value === String(value) ? { ok: true, written: el.value } : { ok: false, reason: 'value-rejected' };
    }

    /** Scrolls a field into view and flashes an outline so the user sees which one it is. */
    function highlight(el, colour = '#4f46e5') {
        if (!el) return;
        el.scrollIntoView({ block: 'center', behavior: 'smooth' });
        const previous = el.style.outline;
        const previousOffset = el.style.outlineOffset;
        el.style.outline = `2px solid ${colour}`;
        el.style.outlineOffset = '2px';
        setTimeout(() => {
            el.style.outline = previous;
            el.style.outlineOffset = previousOffset;
        }, 1600);
    }

    /**
     * TAXISnet validates amounts as `^[-]?[0-9]{1}[0-9]{0,15}(,[0-9][0-9]?)?$` — a
     * comma, never a dot — and PART 5 C's "Amount paid" takes whole euro only. A payload
     * stored by a calculator older than 22 Sep 2026 carries "1461.61" and "4105.68",
     * which the portal rejects on "Calculation of TOTALS". Anything that is not a plain
     * amount is returned unchanged.
     */
    function taxisnetAmount(value, wholeEuro = false) {
        const text = String(value ?? '').trim();
        const match = text.match(/^(-?\d+)(?:[.,](\d{1,2}))?$/);
        if (!match) return text;
        if (wholeEuro) return String(Math.round(Number(`${match[1]}.${match[2] ?? '0'}`)));
        return match[2] === undefined ? match[1] : `${match[1]},${match[2]}`;
    }

    globalThis.CyTd1Locator = {
        FILLABLE_SELECTOR,
        taxisnetAmount,
        describe,
        resolve,
        fill,
        highlight,
        isFillable,
        toFillableTarget,
        guessLabel,
    };
})();
